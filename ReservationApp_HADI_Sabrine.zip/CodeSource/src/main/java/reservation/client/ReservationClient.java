package reservation.client;
import reservation.model.*;import java.io.*;import java.net.*;
public class ReservationClient implements Closeable {
 private Socket socket;private ObjectOutputStream out;private ObjectInputStream in;
 public ReservationClient(String host,int port)throws IOException{socket=new Socket(host,port);out=new ObjectOutputStream(socket.getOutputStream());out.flush();in=new ObjectInputStream(socket.getInputStream());}
 public synchronized Response send(String action,Object data)throws Exception{out.writeObject(new Request(action,data));out.flush();out.reset();return (Response)in.readObject();}
 public void close(){try{socket.close();}catch(Exception e){}}
}

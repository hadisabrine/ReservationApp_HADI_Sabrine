package reservation.model;
import java.io.Serializable;
public class Request implements Serializable {
 private static final long serialVersionUID=1L;
 public String action; public Object data;
 public Request(String action,Object data){this.action=action;this.data=data;}
}

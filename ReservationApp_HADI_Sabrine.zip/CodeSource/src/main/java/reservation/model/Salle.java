package reservation.model;
import java.io.Serializable;
public class Salle implements Serializable {
 private static final long serialVersionUID=1L;
 public int id,capacite; public String nom,type; public boolean disponible;
 public Salle(int id,String nom,String type,int capacite,boolean disponible){this.id=id;this.nom=nom;this.type=type;this.capacite=capacite;this.disponible=disponible;}
 public String toString(){return id+" - "+nom+" ("+capacite+")";}
}

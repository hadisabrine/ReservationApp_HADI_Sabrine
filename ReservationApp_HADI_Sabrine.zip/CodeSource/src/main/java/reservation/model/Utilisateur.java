package reservation.model;
import java.io.Serializable;
public class Utilisateur implements Serializable {
 private static final long serialVersionUID=1L;
 public int id; public String nom,email,motDePasse,role;
 public Utilisateur(int id,String nom,String email,String motDePasse,String role){this.id=id;this.nom=nom;this.email=email;this.motDePasse=motDePasse;this.role=role;}
 public String toString(){return nom+" ("+email+")";}
}

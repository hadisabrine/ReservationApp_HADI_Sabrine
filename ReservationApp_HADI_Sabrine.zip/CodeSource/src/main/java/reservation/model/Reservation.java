package reservation.model;
import java.io.Serializable;
public class Reservation implements Serializable {
 private static final long serialVersionUID=1L;
 public int id,idUtilisateur,idSalle; public String date,heureDebut,heureFin,motif,statut,nomUtilisateur,nomSalle;
 public Reservation(int id,int idUtilisateur,int idSalle,String date,String debut,String fin,String motif,String statut){this.id=id;this.idUtilisateur=idUtilisateur;this.idSalle=idSalle;this.date=date;heureDebut=debut;heureFin=fin;this.motif=motif;this.statut=statut;}
 public Object[] toRow(){return new Object[]{id,nomUtilisateur,idSalle,nomSalle,date,heureDebut,heureFin,motif,statut};}
}

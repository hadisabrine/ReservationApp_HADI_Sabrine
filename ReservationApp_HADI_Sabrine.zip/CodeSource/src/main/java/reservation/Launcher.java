package reservation;

import reservation.client.ClientGUI;
import reservation.server.ReservationServer;

public class Launcher {
    public static void main(String[] args) throws Exception {
        if (args.length > 0 && args[0].equals("serveur")) {
            ReservationServer.main(args);
        } else {
            ClientGUI.main(args);
        }
    }
}
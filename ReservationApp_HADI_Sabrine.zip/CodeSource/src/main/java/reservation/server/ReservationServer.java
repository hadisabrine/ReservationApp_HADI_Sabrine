package reservation.server;

import reservation.db.DatabaseConnection;
import reservation.db.ReservationDAO;
import java.net.InetAddress;
import java.net.ServerSocket;

public class ReservationServer {
    public static void main(String[] args) throws Exception {
        int port = Integer.getInteger("reservation.port", 5000);
        var dao = new ReservationDAO();
        try (var server = new ServerSocket(port, 50, InetAddress.getByName("127.0.0.1"))) {
            DatabaseConnection.initialize();
            System.out.println("Serveur démarré sur le port " + port);
            while (true) {
                new Thread(new ClientHandler(server.accept(), dao)).start();
            }
        }
    }
}
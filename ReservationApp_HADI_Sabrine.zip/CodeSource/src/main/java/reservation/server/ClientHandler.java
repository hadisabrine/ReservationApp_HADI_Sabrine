package reservation.server;
import reservation.db.ReservationDAO;import reservation.model.*;import java.io.*;import java.net.*;import java.time.LocalDateTime;import java.nio.file.*;
public class ClientHandler implements Runnable {
 private final Socket socket;private final ReservationDAO dao;
 public ClientHandler(Socket socket,ReservationDAO dao){this.socket=socket;this.dao=dao;}
 public void run(){try(ObjectOutputStream out=new ObjectOutputStream(socket.getOutputStream());){out.flush();try(ObjectInputStream in=new ObjectInputStream(socket.getInputStream())){while(true){Request req=(Request)in.readObject();Response res=dao.execute(req);log(req,res);out.writeObject(res);out.flush();out.reset();}}}catch(Exception e){}finally{try{socket.close();}catch(Exception e){}}}
 private void log(Request q,Response r){try{String line=LocalDateTime.now()+" | "+q.action+" | "+r.message+System.lineSeparator();Files.writeString(Path.of("files/logs.txt"),line,StandardOpenOption.CREATE,StandardOpenOption.APPEND);}catch(Exception e){}}
}

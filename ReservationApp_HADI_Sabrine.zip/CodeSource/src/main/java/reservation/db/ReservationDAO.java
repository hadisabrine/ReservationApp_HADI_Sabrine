package reservation.db;
import reservation.model.*;
import java.sql.*;
import java.util.*;

public class ReservationDAO {
 public synchronized Response execute(Request req) {
  try {
   switch(req.action) {
    case "LOGIN": return login((Map<String,Object>)req.data);
    case "ROOMS": return rooms();
    case "RESERVATIONS": return reservations();
    case "ADD_RESERVATION": return saveReservation((Map<String,Object>)req.data,false);
    case "UPDATE_RESERVATION": return saveReservation((Map<String,Object>)req.data,true);
    case "DELETE_RESERVATION": return deleteReservation((Integer)req.data);
    case "ADD_ROOM": return saveRoom((Map<String,Object>)req.data,false);
    case "UPDATE_ROOM": return saveRoom((Map<String,Object>)req.data,true);
    case "DELETE_ROOM": return deleteRoom((Integer)req.data);
    case "STATS": return stats();
    default: return new Response(false,"Opération inconnue",null);
   }
  } catch(Exception e){return new Response(false,e.getMessage(),null);}
 }
 private Response login(Map<String,Object> m)throws SQLException {
  try(Connection c=DatabaseConnection.getConnection();PreparedStatement p=c.prepareStatement("SELECT id,nom,email,motDePasse,role FROM Utilisateur WHERE email=? AND motDePasse=?")){
   p.setString(1,(String)m.get("email"));p.setString(2,(String)m.get("password"));
   try(ResultSet r=p.executeQuery()){if(r.next())return new Response(true,"Authentification réussie",new Utilisateur(r.getInt(1),r.getString(2),r.getString(3),"",r.getString(5)));}
  } return new Response(false,"Email ou mot de passe incorrect",null);
 }
 private Response rooms()throws SQLException {
  List<Salle> l=new ArrayList<>();try(Connection c=DatabaseConnection.getConnection();Statement s=c.createStatement();ResultSet r=s.executeQuery("SELECT id,nom,type,capacite,disponible FROM Salle ORDER BY id")){
   while(r.next())l.add(new Salle(r.getInt(1),r.getString(2),r.getString(3),r.getInt(4),r.getInt(5)==1));}
  return new Response(true,"",l);
 }
 private Response reservations()throws SQLException {
  List<Reservation> l=new ArrayList<>();String q="SELECT r.id,r.idUtilisateur,r.idSalle,TO_CHAR(r.dateReservation,'YYYY-MM-DD'),r.heureDebut,r.heureFin,r.motif,r.statut,u.nom,s.nom FROM Reservation r JOIN Utilisateur u ON u.id=r.idUtilisateur JOIN Salle s ON s.id=r.idSalle ORDER BY r.dateReservation,r.heureDebut";
  try(Connection c=DatabaseConnection.getConnection();Statement st=c.createStatement();ResultSet r=st.executeQuery(q)){while(r.next()){Reservation x=new Reservation(r.getInt(1),r.getInt(2),r.getInt(3),r.getString(4),r.getString(5),r.getString(6),r.getString(7),r.getString(8));x.nomUtilisateur=r.getString(9);x.nomSalle=r.getString(10);l.add(x);}}
  return new Response(true,"",l);
 }
 private Response saveReservation(Map<String,Object> m,boolean update)throws SQLException {
  int id=update ? num(m,"id") : 0,uid=num(m,"idUtilisateur"),rid=num(m,"idSalle");String date=str(m,"date"),start=str(m,"heureDebut"),end=str(m,"heureFin"),motif=str(m,"motif"),status=str(m,"statut");
  if(start.compareTo(end)>=0)return new Response(false,"L'heure de début doit précéder l'heure de fin",null);
  try(Connection c=DatabaseConnection.getConnection()){
   c.setAutoCommit(false);
   try {
    try (PreparedStatement lock = c.prepareStatement("SELECT id FROM Salle WHERE id=? AND disponible=1 FOR UPDATE")) {
     lock.setInt(1,rid);
     try (ResultSet room = lock.executeQuery()) {
      if (!room.next()) {
       c.rollback();
       return new Response(false,"Salle indisponible",null);
      }
     }
    }
    String overlap="SELECT COUNT(*) FROM Reservation WHERE idSalle=? AND dateReservation=TO_DATE(?,'YYYY-MM-DD') AND statut<>'ANNULEE' AND heureDebut<? AND heureFin>?"+(update?" AND id<>?":"");
    try(PreparedStatement p=c.prepareStatement(overlap)){p.setInt(1,rid);p.setString(2,date);p.setString(3,end);p.setString(4,start);if(update)p.setInt(5,id);try(ResultSet r=p.executeQuery()){r.next();if(r.getInt(1)>0){c.rollback();return new Response(false,"Salle indisponible : chevauchement avec une réservation existante",null);}}}
    String sql=update?"UPDATE Reservation SET idUtilisateur=?,idSalle=?,dateReservation=TO_DATE(?,'YYYY-MM-DD'),heureDebut=?,heureFin=?,motif=?,statut=? WHERE id=?":"INSERT INTO Reservation(idUtilisateur,idSalle,dateReservation,heureDebut,heureFin,motif,statut) VALUES(?,?,TO_DATE(?,'YYYY-MM-DD'),?,?,?,?)";
    try(PreparedStatement p=c.prepareStatement(sql)){p.setInt(1,uid);p.setInt(2,rid);p.setString(3,date);p.setString(4,start);p.setString(5,end);p.setString(6,motif);p.setString(7,status);if(update)p.setInt(8,id);int n=p.executeUpdate();if(n==0){c.rollback();return new Response(false,"Réservation introuvable",null);}}
    c.commit();return new Response(true,update?"Réservation modifiée":"Réservation ajoutée",null);
   } catch(Exception e){c.rollback();throw e;} finally{c.setAutoCommit(true);}
  }
 }
 private Response deleteReservation(int id)throws SQLException {try(Connection c=DatabaseConnection.getConnection();PreparedStatement p=c.prepareStatement("DELETE FROM Reservation WHERE id=?")){p.setInt(1,id);return new Response(p.executeUpdate()>0,"Suppression effectuée",null);}}
 private Response saveRoom(Map<String,Object> m,boolean update)throws SQLException {String sql=update?"UPDATE Salle SET nom=?,type=?,capacite=?,disponible=? WHERE id=?":"INSERT INTO Salle(nom,type,capacite,disponible) VALUES(?,?,?,?)";try(Connection c=DatabaseConnection.getConnection();PreparedStatement p=c.prepareStatement(sql)){p.setString(1,str(m,"nom"));p.setString(2,str(m,"type"));p.setInt(3,num(m,"capacite"));p.setInt(4,bool(m,"disponible")?1:0);if(update)p.setInt(5,num(m,"id"));int n=p.executeUpdate();return new Response(n>0,update?"Salle modifiée":"Salle ajoutée",null);}}
 private Response deleteRoom(int id)throws SQLException {try(Connection c=DatabaseConnection.getConnection();PreparedStatement p=c.prepareStatement("DELETE FROM Salle WHERE id=?")){p.setInt(1,id);return new Response(p.executeUpdate()>0,"Salle supprimée",null);}}
 private Response stats()throws SQLException {Map<String,Integer> m=new HashMap<>();try(Connection c=DatabaseConnection.getConnection();Statement s=c.createStatement()){try(ResultSet r=s.executeQuery("SELECT COUNT(*) FROM Reservation WHERE statut<>'ANNULEE'")){r.next();m.put("reservations",r.getInt(1));}try(ResultSet r=s.executeQuery("SELECT COUNT(*) FROM Salle")){r.next();m.put("salles",r.getInt(1));}try(ResultSet r=s.executeQuery("SELECT COUNT(*) FROM Reservation WHERE TRUNC(dateReservation)=TRUNC(SYSDATE) AND statut<>'ANNULEE'")){r.next();m.put("today",r.getInt(1));}}return new Response(true,"",m);}
 private static String str(Map<String,Object> m,String k){return String.valueOf(m.get(k));} private static int num(Map<String,Object> m,String k){return ((Number)m.get(k)).intValue();} private static boolean bool(Map<String,Object> m,String k){return Boolean.TRUE.equals(m.get(k));}
}

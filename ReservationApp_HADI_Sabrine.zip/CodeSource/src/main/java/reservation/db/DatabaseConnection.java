package reservation.db;

import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import org.h2.tools.RunScript;

public class DatabaseConnection {
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:h2:./ReservationDB;MODE=Oracle", "sa", "");
    }

    public static void initialize() throws Exception {
        Files.createDirectories(Path.of("files"));
        if (Files.exists(Path.of("ReservationDB.mv.db"))) {
            return;
        }
        try (var connection = getConnection();
             var reader = new InputStreamReader(
                 DatabaseConnection.class.getResourceAsStream("/ReservationDB.sql"), StandardCharsets.UTF_8)) {
            RunScript.execute(connection, reader);
        }
    }
}